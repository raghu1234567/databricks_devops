# Databricks notebook source
# MAGIC %run ../../Includes/_common

# COMMAND ----------

DA = DBAcademyHelper()
DA.init()